# Snake Sprint — Firebase Phone Auth version

## Included
- Responsive Snake game
- Firebase Phone Authentication using the supplied Firebase web configuration
- SMS OTP request, OTP confirmation, and resend UI with a 30-second client-side cooldown
- Auth state controls access to the game

## Before testing
1. In Firebase Console, Authentication > Sign-in method, enable Phone.
2. Authentication > Settings > Authorized domains: add `localhost` for local testing and your deployed domain.
3. Authentication settings: allow the SMS regions you intend to serve, such as Bangladesh (+880).
4. Serve this folder from a local web server or Firebase Hosting. Do not open `index.html` as a `file://` URL.
5. Test with Firebase Authentication test phone numbers first. Real SMS availability, quotas, billing, and anti-abuse controls are managed by Firebase.

## Run locally
From this folder, run:
`python -m http.server 8000`
Then open `http://localhost:8000`.

## Important
The 30-second resend cooldown is only a client-side user-interface safeguard, not a secure server-enforced limit. Firebase may independently throttle or block requests. Do not try to bypass provider safeguards or send unlimited SMS. For production, configure Firebase App Check where appropriate and review Firebase Authentication / Security Rules before adding user data.
